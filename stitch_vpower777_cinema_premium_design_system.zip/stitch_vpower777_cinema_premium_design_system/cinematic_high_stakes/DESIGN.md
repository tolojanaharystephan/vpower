---
name: Cinematic High-Stakes
colors:
  surface: '#15130d'
  surface-dim: '#15130d'
  surface-bright: '#3c3932'
  surface-container-lowest: '#100e08'
  surface-container-low: '#1e1b15'
  surface-container: '#221f19'
  surface-container-high: '#2c2a23'
  surface-container-highest: '#37342e'
  on-surface: '#e8e2d7'
  on-surface-variant: '#d3c5ae'
  inverse-surface: '#e8e2d7'
  inverse-on-surface: '#333029'
  outline: '#9b8f7a'
  outline-variant: '#4f4634'
  surface-tint: '#f6be39'
  primary: '#f6be39'
  on-primary: '#402d00'
  primary-container: '#d4a017'
  on-primary-container: '#503a00'
  inverse-primary: '#795900'
  secondary: '#c8c5cb'
  on-secondary: '#303034'
  secondary-container: '#47464b'
  on-secondary-container: '#b6b4ba'
  tertiary: '#cac6be'
  on-tertiary: '#32302b'
  tertiary-container: '#aca8a1'
  on-tertiary-container: '#3f3d38'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdfa0'
  primary-fixed-dim: '#f6be39'
  on-primary-fixed: '#261a00'
  on-primary-fixed-variant: '#5c4300'
  secondary-fixed: '#e4e1e7'
  secondary-fixed-dim: '#c8c5cb'
  on-secondary-fixed: '#1b1b1f'
  on-secondary-fixed-variant: '#47464b'
  tertiary-fixed: '#e7e2da'
  tertiary-fixed-dim: '#cac6be'
  on-tertiary-fixed: '#1d1c17'
  on-tertiary-fixed-variant: '#494741'
  background: '#15130d'
  on-background: '#e8e2d7'
  surface-variant: '#37342e'
typography:
  display-777:
    fontFamily: Syne
    fontSize: 80px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Syne
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
  admin-data:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1440px
---

## Brand & Style
The design system establishes a high-stakes, cinematic atmosphere for a premium gaming platform. It rejects the overused neon aesthetics of generic casinos in favor of a "Dark Cinema" approach—evoking the hushed, exclusive environment of a high-limit lounge.

The style leverages **Minimalism** and **Glassmorphism** with a focus on tactile luxury. Depth is created through subtle radial gradients and light-leaks rather than heavy shadows. The emotional response is one of sophistication, focus, and prestige. The interface should feel "expensive" and "heavy," utilizing expansive whitespace and sharp, intentional accents to guide the user's eye toward opportunities and action.

## Colors
The palette is rooted in deep blacks and "Obsidian" tones to provide maximum contrast for the Amber/Gold accents. 

- **Backgrounds:** Use `#0B0B0F` for client-facing experiences to maintain depth. Use `#08080C` for administrative interfaces to denote a "behind the scenes" operational environment.
- **Accents:** `#D4A017` is the primary action color. It should be used sparingly for critical CTAs, game highlights, and the "777" iconography. 
- **Gradients:** Use radial gradients of `#D4A017` at 5-10% opacity in the background to simulate soft amber spotlights, creating a sense of physical space and "stage lighting" behind game tiles.

## Typography
Typography is a primary differentiator. **Syne** provides an avant-garde, wide-set look for headings that feels contemporary and high-end. **Outfit** provides the technical clarity needed for gaming odds and administrative data.

- **Headlines:** Always use Syne. For major jackpot numbers or section headers, use the "Extra Bold" weight with tight letter spacing.
- **Body & Data:** Outfit is used for all functional text. In admin tables, use `admin-data` to ensure maximum legibility at high densities.
- **Hierarchy:** Use the Muted Text color (`#9A958C`) for labels and secondary information to keep the primary focus on white and gold elements.

## Layout & Spacing
The layout follows a **Fluid Grid** model with generous margins to reinforce the premium aesthetic.

- **Grid:** 12-column system for desktop.
- **Rhythm:** All spacing (padding, margins) must be multiples of 4px. Use `24px` (6 units) as the standard gutter between game tiles.
- **Admin Layout:** High-density views should use a narrower 16px gutter to maximize data visibility, while client-facing lobby views should use 32px-48px vertical rhythm to create a more relaxed, "editorial" feel.
- **Safe Areas:** Ensure content is contained within a 1440px max-width to prevent line-lengths from becoming unreadable on ultra-wide monitors.

## Elevation & Depth
Depth is achieved through **Tonal Layers** and **Ambient Light**. 

- **Base Level:** `#0B0B0F` (Pure depth).
- **Surface Level:** `#14141A` used for cards, navigation bars, and drawers.
- **Elevated Level:** Use a subtle `1px` border of `rgba(245, 240, 232, 0.1)` on all cards. 
- **Hover States:** When a game tile or button is hovered, increase the border opacity and add a soft amber outer glow: `0 0 20px rgba(212, 160, 23, 0.15)`. This simulates the tile "powering on."
- **Backdrop Blur:** Modals and drawers should use a `20px` backdrop filter blur with a 60% opacity fill of the background color to maintain context without visual noise.

## Shapes
The shape language is "Soft-Modern"—sharp enough to feel professional and technical, but rounded enough to feel premium and tactile.

- **Buttons & Cards:** 4px (`rounded-sm`) to 8px (`rounded-md`).
- **Game Tiles:** Use 8px corner radius.
- **Form Inputs:** 4px corner radius to maintain a structured, "bank-grade" feel.
- **Icons:** Use linear, 1.5px stroke weight icons. Avoid filled icons unless it is the gold "777" mark.

## Components

### Premium Game Tiles
Tiles should have a `16:9` or `4:5` aspect ratio. On hover, the image should scale slightly (1.05x) and the amber border should transition from `0.1` to `0.4` opacity. Include a "Play" overlay that uses the Amber primary color.

### Orbital AI Loader
A custom animation consisting of two concentric amber rings. The outer ring rotates clockwise at a slow pace, while the inner ring pulses and rotates counter-clockwise. This is used for "Checking Balance" or "Loading Game" states.

### 777 Gold Coin Mark
The brand's signature element. It should be rendered as a vector with a subtle linear gradient (from `#D4A017` to `#B8860B`) to simulate gold leaf. Use it as a watermark in high-end drawers and as a currency symbol for platform credits.

### High-Density Admin Tables
Rows should be `#121218` with a height of `48px`. Use `Outfit` at 14px. Status indicators (Active, Suspended, Flagged) should use low-saturation pips with a soft glow rather than bright solid colors.

### Buttons
- **Primary:** Background `#D4A017`, Text `#0B0B0F`, Bold Outfit.
- **Secondary:** Transparent background, `1px` border of `rgba(212, 160, 23, 0.5)`, Text `#D4A017`.
- **Support 'Care' Buttons:** Use larger padding and a subtle `rgba(212, 160, 23, 0.05)` background to feel more "organic" and approachable.

### Input Fields
Inputs should have a dark fill (`#08080C`) and a bottom-only border by default, which transitions to a full border on focus. This mimics luxury boutique digital experiences.